﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class HomePage : System.Web.UI.Page
{
    //string ConnectionString = @"Data Source=(LocalDb)\MSSqlLocalDb;Initial Catalog=Suraj;Integrated Security=True;Pooling=False";
    protected void Page_Load(object sender, EventArgs e)
    {
        //string con = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        //using (SqlConnection conn = new SqlConnection(con))
        //{

        //    using (SqlDataAdapter sda = new SqlDataAdapter("select Title,Original_price,Pic from Books", conn))
        //    {
        //        DataTable dt = new DataTable();
        //        sda.Fill(dt);
        //        DataList1.DataSource = dt;
        //        DataList1.DataBind();

        //    }

        //    //protected void OnRowDataBound(object sender, GridViewRowEventArgs e)
        //    //{
        //    //    if (e.Row.RowType == DataControlRowType.DataRow)
        //    //    {
        //    //        DataRowView dr = (DataRowView)e.Row.DataItem;
        //    //        string imageUrl = "data:image/jpg;base64," + Convert.ToBase64String((byte[])dr["Data"]);
        //    //        (e.Row.FindControl("Image1") as Image).ImageUrl = imageUrl;
        //    //    }
        //    //}





        //}

        if (!IsPostBack)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"Data Source=(LocalDb)\MSSqlLocalDb;Initial Catalog=Suraj;Integrated Security=True;Pooling=False";

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select Pic ,Title,Selling_price from Books";

            con.Open();

            SqlDataAdapter sda = new SqlDataAdapter();
            sda.SelectCommand = cmd;
            DataSet ds = new DataSet();
            sda.Fill(ds, "Books");
            GridView1.DataSource = ds.Tables["Books"];
            GridView1.DataBind();

        }
    }



    protected void OnRowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataRowView dr = (DataRowView)e.Row.DataItem;
            string imageUrl = "data:image/jpg;base64," + Convert.ToBase64String((byte[])dr["Pic"]);
            (e.Row.FindControl("Image1") as Image).ImageUrl = imageUrl;
           
        }

    }





    protected void btn_next_Click(object sender, EventArgs e)
    {
        
    }
}






    
